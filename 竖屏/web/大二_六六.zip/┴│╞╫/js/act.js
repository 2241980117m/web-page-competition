
		$(function(){
		
			$.fn.fullpage({
		
				slidesColor: ['#1bbc9b', '#4BBFC3', '#7BAABE', '#f90'],
		
				anchors: ['page1', 'page2', 'page3', 'page4','page5','page6'],
		
				
				menu: '#menu',
				
				verticalCentered:true
			});
			
		
		});